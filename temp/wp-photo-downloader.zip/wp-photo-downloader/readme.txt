=== WP Photo Downloader ===
Contributors: Mikoviny,
Donate link: http://artificium.sk
Tags: post, page, media library, pictures
Requires at least: 3.1
Tested up to: 3.1
Stable tag: 1.0

This plugin is saving pictures used in the posts from other sites (ctr+c & ctr+v) to own server and add to media library.

== Description ==
This plugin is saving pictures used in the posts from other sites (ctr+c & ctr+v) to own server and add to media library.

= How to use this plugin =
* Just copy paste picture to post/page from other web page. By saving post/page all used pictures from other web pages download and save to your own server. Pictures are automatic added to media library. There are no setting by this plugin.
* Now I noticed that pictures are adding twice and don�t know if it�s bug or some collision with other plugin... and have no time for now... :(


== Installation ==

1. Upload `plugin-name.php` to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress



